#!/usr/bin/env python
from setuptools import find_packages, setup

setup(name='simplewheel',
      version='2.0',
      packages=find_packages()
      )
